<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>not_allow</title>
</head>
<body>
    <h1>Acesso não permitido</h1>
    <p>Você não tem permissão para acessar esta página.</p>
    <p>entre em contato com o administrador se você acredita que isso é um erro.</p>
</body>
</html>