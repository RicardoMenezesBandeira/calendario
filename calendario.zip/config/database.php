<?php
/
 
Configuração centralizada do banco de dados
Evita repetição de credenciais e conexões em múltiplos arquivos*/

define('DB_HOST', 'sql211.infinityfree.com');
define('DB_NAME', 'if0_40537201_sistema_gestao');
define('DB_USER', 'if0_40537201');
define('DB_PASS', 'fBuWec89gU');

/
 
Função para obter conexão PDO
Reutilizável em qualquer arquivo do projeto*/
function getPDO() {
    try {
        $pdo = new PDO(
            "mysql:dbname=" . DB_NAME . ";host=" . DB_HOST,
            DB_USER,
            DB_PASS,
            array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION)
        );
        return $pdo;
    } catch (PDOException $e) {
        die(json_encode(["erro" => "Erro de conexão: " . $e->getMessage()]));
    }
}
?>